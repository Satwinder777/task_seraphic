package com.example.task_satwinder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
